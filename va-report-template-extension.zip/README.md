# VA Report Starter (Template Extension)

Use this with Quarto's template command:

```sh
quarto use template <your-org-or-username>/va-report-template-extension
```

This will scaffold a new project that already includes the VA Lab theme and defaults.
